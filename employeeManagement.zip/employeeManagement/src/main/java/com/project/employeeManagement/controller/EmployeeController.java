package com.project.employeeManagement.controller;

import com.project.employeeManagement.model.EmployeeDetails;
import com.project.employeeManagement.service.EmployeeService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

@RestController
public class EmployeeController {

    public static final Logger logger = LogManager.getLogger( EmployeeController.class );

    @Autowired
    EmployeeService service;
    
    @GetMapping("/employees")
    public ResponseEntity<List<EmployeeDetails>> getAllEmployees(
            Pageable pageable)
    {
        logger.info( "Getting all the employees data..." );
        logger.info( " The page number is : [" + pageable.getPageNumber() + "]" );
        logger.info( " The page Size is : [" + pageable.getPageSize() + "]" );
        logger.info( " The data is sorted by : [" + pageable.getSort() + "]" );

        List<EmployeeDetails> employeeDetails = service.getAllEmployees(pageable);


        return new ResponseEntity<List<EmployeeDetails>>(employeeDetails, new HttpHeaders(), HttpStatus.OK);
    }

    // Insert new employee record
    @PostMapping("/employees")
    @ResponseStatus(HttpStatus.CREATED)
    public HttpStatus addEmployee(@RequestBody EmployeeDetails employee)
    {
        logger.info(" The new employee details are as follows ..." );
        logger.info( " Name : [" + employee.getName()+ "]" );
        logger.info( " Phone Number : [" + employee.getPhoneNumber() + "]" );
        logger.info( " Address : [" + employee.getAddress() + "]" );

        logger.info( "Adding New employee...." );

        if(employee!= null)
        {
            service.addEmployee(employee);
            return HttpStatus.CREATED;

        }
        else
        {
            logger.error( " Enter employee details!!!"  );
            return HttpStatus.BAD_REQUEST;
        }
    }

    //Updating a employees's details
    @PutMapping("employees/{id}")
    public ResponseEntity<String> updateUser(
            @PathVariable(name = "id") Long id,
            @RequestBody EmployeeDetails employee) {

            employee.setId(id);

        try {
            //Displaying old User Data
            logger.info(" The old  details of employee are : ");
            EmployeeDetails oldEntity = service.getEmplyeeById(employee.getId());
            logger.info(" Name : [" + oldEntity.getName() + "]");
            logger.info(" Phone Number : [" + oldEntity.getPhoneNumber() + "]");
            logger.info(" Address : [" + oldEntity.getAddress() + "]");

            //Displaying new user data
            logger.info(" The new user details are as follows ...");
            logger.info(" Name : [" + employee.getName() + "]");
            logger.info(" Phone Number : [" + employee.getPhoneNumber() + "]");
            logger.info(" Address : [" + employee.getAddress() + "]");


            logger.info("Updating the User Details....");

            service.updateEmployee(employee);
            return new ResponseEntity<String>(HttpStatus.OK);
        } catch (NoSuchElementException ex) {
            // log the error message
            logger.error(ex.getMessage());
            return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
        }
    }

    //Deleting the user by Id
    @DeleteMapping("/employees")
    public HttpStatus deleteUserById(@RequestBody final Map<String, Set<Long>> requestBody)
    {
       Set<Long> id = requestBody.get("id");
        logger.trace( " The id of the user data to be deleted is :[" + id +"]"  );
        logger.info( " Deleting the user data with Id : [" + id + "]" );
        service.deleteEmployee(id);

        return HttpStatus.OK;
    }
}
