package com.project.employeeManagement.dao;

import com.project.employeeManagement.Dto.EmployeeDto;
import com.project.employeeManagement.model.EmployeeDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.Set;

@Repository
public interface EmployeeDetailsRepository extends JpaRepository<EmployeeDetails,Long> {


    @Transactional
    @Query(value = "SELECT * FROM employee_details where id IN (:ids)", nativeQuery = true)
    Optional<EmployeeDetails> findAllByIdIn(@Param("ids") Set<Long> ids);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM employee_details where id IN (:ids)", nativeQuery = true)
    void deleteByIdIn(@Param("ids") Set<Long> ids);

}
